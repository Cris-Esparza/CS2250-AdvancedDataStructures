// TODO: Guard the header

// TODO: include the libraries this class will need

enum Color;		// TODO: create the color values

class Trophy;	// TODO: complete the Trophy class

// TODO: end the guard